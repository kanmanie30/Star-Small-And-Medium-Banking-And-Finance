package login.submit.registration;

public interface Myprovider {

}
